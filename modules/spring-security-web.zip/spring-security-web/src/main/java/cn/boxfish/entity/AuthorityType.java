package cn.boxfish.entity;

/**
 * Created by LuoLiBing on 15/8/31.
 */
public enum AuthorityType {
    READ,WRITE,DELETE
}
