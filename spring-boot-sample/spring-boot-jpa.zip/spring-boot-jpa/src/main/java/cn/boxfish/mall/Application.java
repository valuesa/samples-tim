package cn.boxfish.mall;

import cn.boxfish.mall.entity.Order;
import cn.boxfish.mall.entity.OrderProduct;
import cn.boxfish.mall.entity.Service;
import cn.boxfish.mall.entity.WorkOrder;
import cn.boxfish.mall.entity.jpa.OrderJpaRepository;
import cn.boxfish.mall.entity.jpa.OrderProductJpaRepository;
import cn.boxfish.mall.entity.jpa.ServiceJpaRepository;
import cn.boxfish.mall.entity.jpa.WorkOrderJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

/**
 * Created by LuoLiBing on 16/2/29.
 */
@SpringBootApplication
@RestController
public class Application {

    @Autowired
    ServiceJpaRepository serviceJpaRepository;

    @Autowired
    WorkOrderJpaRepository workOrderJpaRepository;

    @Autowired
    OrderJpaRepository orderJpaRepository;

    @Autowired
    OrderProductJpaRepository orderProductJpaRepository;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    @RequestMapping(value = "/service/{id}", method = RequestMethod.GET)
    public Service service(@PathVariable Long id) {
        return serviceJpaRepository.findOne(id);
    }

    @RequestMapping(value = "/workorder/{id}", method = RequestMethod.GET)
    public WorkOrder workorder(@PathVariable Long id) {
        return workOrderJpaRepository.findOne(id);
    }

    @RequestMapping(value = "/service/save", method = RequestMethod.GET)
    public Service serviceSave() {

        Service service = new Service();
        service.setProductSkuName("测试" + new Random().nextInt(100));
        final WorkOrder workOrder = new WorkOrder();
        workOrder.setStatus("服务完成");
        service.addWorkOrder(workOrder);
        return serviceJpaRepository.save(service);
    }

    @RequestMapping(value = "/order/update/{id}", method = RequestMethod.GET)
    public Order orderSave(@PathVariable Long id) {
        Order order = orderJpaRepository.findOne(id);
        order.setCode(2000111l);
        order.removeOrderProduct(98l);
        order.removeOrderProduct(99l);

        OrderProduct product1 = new OrderProduct();
        product1.setName("商品1");
        order.addOrderProduct(product1);

        OrderProduct product2 = new OrderProduct();
        product2.setName("商品2");
        order.addOrderProduct(product2);
        return orderJpaRepository.save(order);
    }

}
